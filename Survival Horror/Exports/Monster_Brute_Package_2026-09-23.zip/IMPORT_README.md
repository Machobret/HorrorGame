# Monster Brute package — 2026-09-23

## Contents
- Current Monster_Brute prefab, model, materials, textures, animation controller and supporting scripts.
- Hunched body, continuous arms, flat soles, dark pants, bruised skin and raised acid boils.
- Acid mist, damage toggle, movement-compatible acid reaction and navigation bake menu.
- Editable Blender source, model generator, texture source, current pose previews and validation notes.
- Two required HorrorEngine combat-script changes, with their Unity .meta files and a patch for review.

This is an update package for the existing HorrorGame project using Retro Horror Template. It is not a standalone Unity project or a .unitypackage. The base Monster prefab, template animations, shaders and HorrorEngine systems must already be installed with their original GUIDs. The companion Runner and unrelated scene/project edits are not included.

## Import
1. Exit Play Mode. Back up or commit the destination project's current changes.
2. Extract the ZIP to a temporary folder.
3. Copy the included Assets folder into the Unity project root (the folder containing Assets, Packages and ProjectSettings), preserving paths and .meta files. Merge folders.
4. The supplied AttackBase.cs and Damageable.cs replace those two template files. If your copies contain other changes, merge RequiredCombatChanges.patch instead. Both changes are needed so acid can damage without restarting the player's Hurt state.
5. Copy ArtSource if you want the editable Blender model and generator. It is not required to play.
6. Let Unity import and compile. Use Assets/Game/Enemies/Monster_Brute.prefab. BruteVisualModel automatically creates the visible model from Resources and maps the new rig's clips to the existing combat Animator.
7. Enable Damage on Brute Combat Controller when desired; it is off by default. The Brute has 8 HP.
8. For pursuit, use a baked NavMesh. The included Tools > Horror Game > Bake Navigation for Open Scene command uses Default-layer floor and wall colliders. Save the scene after the bake.

## Editing
Open ArtSource/Brute/Monster_Brute.blend. The generator build_brute.py currently contains the original machine's absolute project path; change ROOT before regenerating on another computer. Preserve model clip names and Unity asset GUIDs.

## Validation
Validated with Unity 6000.3.11f1 in an isolated project: FBX import, animation mappings, rig bindings, pants material, dark skin tint, grounded soles and attack deformation. Full project C# compilation passed. Standing, walking and attacking poses were inspected in Blender. Live gameplay in the destination scene remains to be checked.

MANIFEST.json lists SHA-256 hashes for every packaged project file.
